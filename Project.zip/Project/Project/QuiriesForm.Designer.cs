﻿namespace Project
{
    partial class QuiriesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuiriesForm));
            this.clearButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.savePictureBox = new System.Windows.Forms.PictureBox();
            this.firstPictureBox = new System.Windows.Forms.PictureBox();
            this.lastPictureBox = new System.Windows.Forms.PictureBox();
            this.previousPictureBox = new System.Windows.Forms.PictureBox();
            this.NextPictureBox = new System.Windows.Forms.PictureBox();
            this.customerCPRGroupBox = new System.Windows.Forms.GroupBox();
            this.DisplayByCPRButton = new System.Windows.Forms.Button();
            this.CPRTextBox = new System.Windows.Forms.TextBox();
            this.searchByPriceGroupBox = new System.Windows.Forms.GroupBox();
            this.displaybtwButton = new System.Windows.Forms.Button();
            this.toTextBox = new System.Windows.Forms.TextBox();
            this.fromTextBox = new System.Windows.Forms.TextBox();
            this.toLabel = new System.Windows.Forms.Label();
            this.fromLabel = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.orderIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerCPRDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deliveryTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivalDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.packageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ordersQuieriesDatabaseDataSet = new Project.OrdersQuieriesDatabaseDataSet();
            this.SearchByDescGroupBox = new System.Windows.Forms.GroupBox();
            this.displayByDescutton = new System.Windows.Forms.Button();
            this.descTextBox = new System.Windows.Forms.TextBox();
            this.displayOptionsGroupBox = new System.Windows.Forms.GroupBox();
            this.totalCostadioButton = new System.Windows.Forms.RadioButton();
            this.maxCostRadioButton = new System.Windows.Forms.RadioButton();
            this.minCostRadioButton = new System.Windows.Forms.RadioButton();
            this.allOrdersRadioButton = new System.Windows.Forms.RadioButton();
            this.displayButton = new System.Windows.Forms.Button();
            this.ordersTableAdapter = new Project.OrdersQuieriesDatabaseDataSetTableAdapters.OrdersTableAdapter();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.savePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lastPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.previousPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NextPictureBox)).BeginInit();
            this.customerCPRGroupBox.SuspendLayout();
            this.searchByPriceGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersQuieriesDatabaseDataSet)).BeginInit();
            this.SearchByDescGroupBox.SuspendLayout();
            this.displayOptionsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.clearButton.Location = new System.Drawing.Point(217, 415);
            this.clearButton.Margin = new System.Windows.Forms.Padding(2);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(102, 31);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.savePictureBox);
            this.panel2.Controls.Add(this.firstPictureBox);
            this.panel2.Controls.Add(this.lastPictureBox);
            this.panel2.Controls.Add(this.previousPictureBox);
            this.panel2.Controls.Add(this.NextPictureBox);
            this.panel2.Location = new System.Drawing.Point(140, 213);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(247, 33);
            this.panel2.TabIndex = 1;
            // 
            // savePictureBox
            // 
            this.savePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("savePictureBox.Image")));
            this.savePictureBox.Location = new System.Drawing.Point(184, 6);
            this.savePictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.savePictureBox.Name = "savePictureBox";
            this.savePictureBox.Size = new System.Drawing.Size(45, 19);
            this.savePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.savePictureBox.TabIndex = 14;
            this.savePictureBox.TabStop = false;
            this.savePictureBox.Click += new System.EventHandler(this.savePictureBox_Click);
            // 
            // firstPictureBox
            // 
            this.firstPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("firstPictureBox.Image")));
            this.firstPictureBox.Location = new System.Drawing.Point(17, 6);
            this.firstPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.firstPictureBox.Name = "firstPictureBox";
            this.firstPictureBox.Size = new System.Drawing.Size(45, 19);
            this.firstPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.firstPictureBox.TabIndex = 12;
            this.firstPictureBox.TabStop = false;
            this.firstPictureBox.Click += new System.EventHandler(this.firstPictureBox_Click);
            // 
            // lastPictureBox
            // 
            this.lastPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("lastPictureBox.Image")));
            this.lastPictureBox.Location = new System.Drawing.Point(60, 6);
            this.lastPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.lastPictureBox.Name = "lastPictureBox";
            this.lastPictureBox.Size = new System.Drawing.Size(45, 19);
            this.lastPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lastPictureBox.TabIndex = 11;
            this.lastPictureBox.TabStop = false;
            this.lastPictureBox.Click += new System.EventHandler(this.lastPictureBox_Click);
            // 
            // previousPictureBox
            // 
            this.previousPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("previousPictureBox.Image")));
            this.previousPictureBox.Location = new System.Drawing.Point(105, 6);
            this.previousPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.previousPictureBox.Name = "previousPictureBox";
            this.previousPictureBox.Size = new System.Drawing.Size(45, 19);
            this.previousPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.previousPictureBox.TabIndex = 10;
            this.previousPictureBox.TabStop = false;
            this.previousPictureBox.Click += new System.EventHandler(this.previousPictureBox_Click);
            // 
            // NextPictureBox
            // 
            this.NextPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("NextPictureBox.Image")));
            this.NextPictureBox.Location = new System.Drawing.Point(144, 6);
            this.NextPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.NextPictureBox.Name = "NextPictureBox";
            this.NextPictureBox.Size = new System.Drawing.Size(45, 19);
            this.NextPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.NextPictureBox.TabIndex = 9;
            this.NextPictureBox.TabStop = false;
            this.NextPictureBox.Click += new System.EventHandler(this.NextPictureBox_Click);
            // 
            // customerCPRGroupBox
            // 
            this.customerCPRGroupBox.Controls.Add(this.DisplayByCPRButton);
            this.customerCPRGroupBox.Controls.Add(this.CPRTextBox);
            this.customerCPRGroupBox.Location = new System.Drawing.Point(387, 48);
            this.customerCPRGroupBox.Name = "customerCPRGroupBox";
            this.customerCPRGroupBox.Size = new System.Drawing.Size(148, 115);
            this.customerCPRGroupBox.TabIndex = 3;
            this.customerCPRGroupBox.TabStop = false;
            this.customerCPRGroupBox.Text = "Search By Customer CPR";
            // 
            // DisplayByCPRButton
            // 
            this.DisplayByCPRButton.Location = new System.Drawing.Point(47, 68);
            this.DisplayByCPRButton.Name = "DisplayByCPRButton";
            this.DisplayByCPRButton.Size = new System.Drawing.Size(51, 27);
            this.DisplayByCPRButton.TabIndex = 1;
            this.DisplayByCPRButton.Text = "Display";
            this.DisplayByCPRButton.UseVisualStyleBackColor = true;
            this.DisplayByCPRButton.Click += new System.EventHandler(this.DisplayByCPRButton_Click);
            // 
            // CPRTextBox
            // 
            this.CPRTextBox.Location = new System.Drawing.Point(15, 39);
            this.CPRTextBox.Name = "CPRTextBox";
            this.CPRTextBox.Size = new System.Drawing.Size(117, 20);
            this.CPRTextBox.TabIndex = 0;
            // 
            // searchByPriceGroupBox
            // 
            this.searchByPriceGroupBox.Controls.Add(this.displaybtwButton);
            this.searchByPriceGroupBox.Controls.Add(this.toTextBox);
            this.searchByPriceGroupBox.Controls.Add(this.fromTextBox);
            this.searchByPriceGroupBox.Controls.Add(this.toLabel);
            this.searchByPriceGroupBox.Controls.Add(this.fromLabel);
            this.searchByPriceGroupBox.Location = new System.Drawing.Point(176, 10);
            this.searchByPriceGroupBox.Name = "searchByPriceGroupBox";
            this.searchByPriceGroupBox.Size = new System.Drawing.Size(200, 100);
            this.searchByPriceGroupBox.TabIndex = 1;
            this.searchByPriceGroupBox.TabStop = false;
            this.searchByPriceGroupBox.Text = "Search By Price";
            // 
            // displaybtwButton
            // 
            this.displaybtwButton.Location = new System.Drawing.Point(143, 45);
            this.displaybtwButton.Name = "displaybtwButton";
            this.displaybtwButton.Size = new System.Drawing.Size(51, 27);
            this.displaybtwButton.TabIndex = 4;
            this.displaybtwButton.Text = "Display";
            this.displaybtwButton.UseVisualStyleBackColor = true;
            this.displaybtwButton.Click += new System.EventHandler(this.displaybtwButton_Click);
            // 
            // toTextBox
            // 
            this.toTextBox.Location = new System.Drawing.Point(61, 63);
            this.toTextBox.Name = "toTextBox";
            this.toTextBox.Size = new System.Drawing.Size(66, 20);
            this.toTextBox.TabIndex = 3;
            // 
            // fromTextBox
            // 
            this.fromTextBox.Location = new System.Drawing.Point(61, 26);
            this.fromTextBox.Name = "fromTextBox";
            this.fromTextBox.Size = new System.Drawing.Size(66, 20);
            this.fromTextBox.TabIndex = 1;
            // 
            // toLabel
            // 
            this.toLabel.AutoSize = true;
            this.toLabel.Location = new System.Drawing.Point(6, 66);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(20, 13);
            this.toLabel.TabIndex = 2;
            this.toLabel.Text = "To";
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.Location = new System.Drawing.Point(6, 29);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(30, 13);
            this.fromLabel.TabIndex = 0;
            this.fromLabel.Text = "From";
            // 
            // dataGridView
            // 
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIDDataGridViewTextBoxColumn,
            this.customerCPRDataGridViewTextBoxColumn,
            this.deliveryTypeDataGridViewTextBoxColumn,
            this.destinationDataGridViewTextBoxColumn,
            this.contentDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.arrivalDateDataGridViewTextBoxColumn,
            this.packageDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView.DataSource = this.ordersBindingSource;
            this.dataGridView.Location = new System.Drawing.Point(13, 260);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(507, 150);
            this.dataGridView.TabIndex = 2;
            // 
            // orderIDDataGridViewTextBoxColumn
            // 
            this.orderIDDataGridViewTextBoxColumn.DataPropertyName = "Order ID";
            this.orderIDDataGridViewTextBoxColumn.HeaderText = "Order ID";
            this.orderIDDataGridViewTextBoxColumn.Name = "orderIDDataGridViewTextBoxColumn";
            this.orderIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customerCPRDataGridViewTextBoxColumn
            // 
            this.customerCPRDataGridViewTextBoxColumn.DataPropertyName = "Customer CPR";
            this.customerCPRDataGridViewTextBoxColumn.HeaderText = "Customer CPR";
            this.customerCPRDataGridViewTextBoxColumn.Name = "customerCPRDataGridViewTextBoxColumn";
            // 
            // deliveryTypeDataGridViewTextBoxColumn
            // 
            this.deliveryTypeDataGridViewTextBoxColumn.DataPropertyName = "Delivery Type";
            this.deliveryTypeDataGridViewTextBoxColumn.HeaderText = "Delivery Type";
            this.deliveryTypeDataGridViewTextBoxColumn.Name = "deliveryTypeDataGridViewTextBoxColumn";
            // 
            // destinationDataGridViewTextBoxColumn
            // 
            this.destinationDataGridViewTextBoxColumn.DataPropertyName = "Destination";
            this.destinationDataGridViewTextBoxColumn.HeaderText = "Destination";
            this.destinationDataGridViewTextBoxColumn.Name = "destinationDataGridViewTextBoxColumn";
            // 
            // contentDataGridViewTextBoxColumn
            // 
            this.contentDataGridViewTextBoxColumn.DataPropertyName = "Content";
            this.contentDataGridViewTextBoxColumn.HeaderText = "Content";
            this.contentDataGridViewTextBoxColumn.Name = "contentDataGridViewTextBoxColumn";
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "Weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "Weight";
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            // 
            // arrivalDateDataGridViewTextBoxColumn
            // 
            this.arrivalDateDataGridViewTextBoxColumn.DataPropertyName = "Arrival Date";
            this.arrivalDateDataGridViewTextBoxColumn.HeaderText = "Arrival Date";
            this.arrivalDateDataGridViewTextBoxColumn.Name = "arrivalDateDataGridViewTextBoxColumn";
            // 
            // packageDataGridViewTextBoxColumn
            // 
            this.packageDataGridViewTextBoxColumn.DataPropertyName = "Package";
            this.packageDataGridViewTextBoxColumn.HeaderText = "Package";
            this.packageDataGridViewTextBoxColumn.Name = "packageDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // ordersBindingSource
            // 
            this.ordersBindingSource.DataMember = "Orders";
            this.ordersBindingSource.DataSource = this.ordersQuieriesDatabaseDataSet;
            // 
            // ordersQuieriesDatabaseDataSet
            // 
            this.ordersQuieriesDatabaseDataSet.DataSetName = "OrdersQuieriesDatabaseDataSet";
            this.ordersQuieriesDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SearchByDescGroupBox
            // 
            this.SearchByDescGroupBox.Controls.Add(this.displayByDescutton);
            this.SearchByDescGroupBox.Controls.Add(this.descTextBox);
            this.SearchByDescGroupBox.Location = new System.Drawing.Point(176, 116);
            this.SearchByDescGroupBox.Name = "SearchByDescGroupBox";
            this.SearchByDescGroupBox.Size = new System.Drawing.Size(200, 65);
            this.SearchByDescGroupBox.TabIndex = 2;
            this.SearchByDescGroupBox.TabStop = false;
            this.SearchByDescGroupBox.Text = "Search By Content Description";
            // 
            // displayByDescutton
            // 
            this.displayByDescutton.Location = new System.Drawing.Point(118, 22);
            this.displayByDescutton.Name = "displayByDescutton";
            this.displayByDescutton.Size = new System.Drawing.Size(51, 27);
            this.displayByDescutton.TabIndex = 1;
            this.displayByDescutton.Text = "Display";
            this.displayByDescutton.UseVisualStyleBackColor = true;
            this.displayByDescutton.Click += new System.EventHandler(this.displayByDescutton_Click);
            // 
            // descTextBox
            // 
            this.descTextBox.Location = new System.Drawing.Point(19, 27);
            this.descTextBox.Name = "descTextBox";
            this.descTextBox.Size = new System.Drawing.Size(66, 20);
            this.descTextBox.TabIndex = 0;
            // 
            // displayOptionsGroupBox
            // 
            this.displayOptionsGroupBox.Controls.Add(this.totalCostadioButton);
            this.displayOptionsGroupBox.Controls.Add(this.maxCostRadioButton);
            this.displayOptionsGroupBox.Controls.Add(this.minCostRadioButton);
            this.displayOptionsGroupBox.Controls.Add(this.allOrdersRadioButton);
            this.displayOptionsGroupBox.Controls.Add(this.displayButton);
            this.displayOptionsGroupBox.Location = new System.Drawing.Point(12, 12);
            this.displayOptionsGroupBox.Name = "displayOptionsGroupBox";
            this.displayOptionsGroupBox.Size = new System.Drawing.Size(143, 167);
            this.displayOptionsGroupBox.TabIndex = 0;
            this.displayOptionsGroupBox.TabStop = false;
            this.displayOptionsGroupBox.Text = "Display Options";
            // 
            // totalCostadioButton
            // 
            this.totalCostadioButton.AutoSize = true;
            this.totalCostadioButton.Location = new System.Drawing.Point(27, 101);
            this.totalCostadioButton.Name = "totalCostadioButton";
            this.totalCostadioButton.Size = new System.Drawing.Size(73, 17);
            this.totalCostadioButton.TabIndex = 3;
            this.totalCostadioButton.TabStop = true;
            this.totalCostadioButton.Text = "Total Cost";
            this.totalCostadioButton.UseVisualStyleBackColor = true;
            // 
            // maxCostRadioButton
            // 
            this.maxCostRadioButton.AutoSize = true;
            this.maxCostRadioButton.Location = new System.Drawing.Point(27, 75);
            this.maxCostRadioButton.Name = "maxCostRadioButton";
            this.maxCostRadioButton.Size = new System.Drawing.Size(93, 17);
            this.maxCostRadioButton.TabIndex = 2;
            this.maxCostRadioButton.TabStop = true;
            this.maxCostRadioButton.Text = "Maximum Cost";
            this.maxCostRadioButton.UseVisualStyleBackColor = true;
            // 
            // minCostRadioButton
            // 
            this.minCostRadioButton.AutoSize = true;
            this.minCostRadioButton.Location = new System.Drawing.Point(27, 50);
            this.minCostRadioButton.Name = "minCostRadioButton";
            this.minCostRadioButton.Size = new System.Drawing.Size(89, 17);
            this.minCostRadioButton.TabIndex = 1;
            this.minCostRadioButton.TabStop = true;
            this.minCostRadioButton.Text = "Minimum cost";
            this.minCostRadioButton.UseVisualStyleBackColor = true;
            // 
            // allOrdersRadioButton
            // 
            this.allOrdersRadioButton.AutoSize = true;
            this.allOrdersRadioButton.Location = new System.Drawing.Point(27, 26);
            this.allOrdersRadioButton.Name = "allOrdersRadioButton";
            this.allOrdersRadioButton.Size = new System.Drawing.Size(70, 17);
            this.allOrdersRadioButton.TabIndex = 0;
            this.allOrdersRadioButton.TabStop = true;
            this.allOrdersRadioButton.Text = "All Orders";
            this.allOrdersRadioButton.UseVisualStyleBackColor = false;
            this.allOrdersRadioButton.CheckedChanged += new System.EventHandler(this.allOrdersRadioButton_CheckedChanged);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(27, 131);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(85, 27);
            this.displayButton.TabIndex = 4;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // ordersTableAdapter
            // 
            this.ordersTableAdapter.ClearBeforeFill = true;
            // 
            // QuiriesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(549, 472);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.customerCPRGroupBox);
            this.Controls.Add(this.searchByPriceGroupBox);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.SearchByDescGroupBox);
            this.Controls.Add(this.displayOptionsGroupBox);
            this.Name = "QuiriesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quiries";
            this.Load += new System.EventHandler(this.QuiriesForm_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.savePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lastPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.previousPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NextPictureBox)).EndInit();
            this.customerCPRGroupBox.ResumeLayout(false);
            this.customerCPRGroupBox.PerformLayout();
            this.searchByPriceGroupBox.ResumeLayout(false);
            this.searchByPriceGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersQuieriesDatabaseDataSet)).EndInit();
            this.SearchByDescGroupBox.ResumeLayout(false);
            this.SearchByDescGroupBox.PerformLayout();
            this.displayOptionsGroupBox.ResumeLayout(false);
            this.displayOptionsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox savePictureBox;
        private System.Windows.Forms.PictureBox firstPictureBox;
        private System.Windows.Forms.PictureBox lastPictureBox;
        private System.Windows.Forms.PictureBox previousPictureBox;
        private System.Windows.Forms.PictureBox NextPictureBox;
        private System.Windows.Forms.GroupBox customerCPRGroupBox;
        private System.Windows.Forms.TextBox CPRTextBox;
        private System.Windows.Forms.GroupBox searchByPriceGroupBox;
        private System.Windows.Forms.Button displaybtwButton;
        private System.Windows.Forms.TextBox toTextBox;
        private System.Windows.Forms.TextBox fromTextBox;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.GroupBox SearchByDescGroupBox;
        private System.Windows.Forms.Button displayByDescutton;
        private System.Windows.Forms.TextBox descTextBox;
        private System.Windows.Forms.GroupBox displayOptionsGroupBox;
        private System.Windows.Forms.RadioButton totalCostadioButton;
        private System.Windows.Forms.RadioButton maxCostRadioButton;
        private System.Windows.Forms.RadioButton minCostRadioButton;
        private System.Windows.Forms.RadioButton allOrdersRadioButton;
        private System.Windows.Forms.Button displayButton;
        private OrdersQuieriesDatabaseDataSet ordersQuieriesDatabaseDataSet;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private OrdersQuieriesDatabaseDataSetTableAdapters.OrdersTableAdapter ordersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerCPRDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivalDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn packageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button DisplayByCPRButton;
    }
}