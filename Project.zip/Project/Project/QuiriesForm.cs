﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class QuiriesForm : Form
    {
        public QuiriesForm()
        {
            InitializeComponent();
        }

        private void QuiriesForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ordersQuieriesDatabaseDataSet.Orders' table. You can move, or remove it, as needed.
            // this.ordersTableAdapter.Fill(this.ordersQuieriesDatabaseDataSet.Orders);

        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (allOrdersRadioButton.Checked)
                {
                    this.ordersTableAdapter.Fill(this.ordersQuieriesDatabaseDataSet.Orders);
                }
                else if(maxCostRadioButton.Checked)
                {
                    int maxUnit;
                    maxUnit = (int)ordersTableAdapter.MaximumCostQuery();
                    MessageBox.Show("Maximam cost : " + maxUnit.ToString());
                }
                else if (minCostRadioButton.Checked)
                {
                    int minUnit;
                    minUnit = (int)ordersTableAdapter.MinimumCostQuery();
                    MessageBox.Show("Minimum cost : " + minUnit.ToString());
                }
                else if (totalCostadioButton.Checked)
                {
                    decimal total;
                    total = (decimal)ordersTableAdapter.TotalCostQuery();
                    MessageBox.Show("Total cost for orders : " + total.ToString("c"));
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void allOrdersRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void displaybtwButton_Click(object sender, EventArgs e)
        {
            try
            {
                decimal from, to;

                if (decimal.TryParse(fromTextBox.Text, out from))
                {
                    if (decimal.TryParse(toTextBox.Text, out to))
                    {
                        ordersTableAdapter.FillByCostBetween(ordersQuieriesDatabaseDataSet.Orders, from, to);
                    }
                    else
                    {
                        MessageBox.Show("Please enter a numeric value");
                        toTextBox.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a numeric value");
                    fromTextBox.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void displayByDescutton_Click(object sender, EventArgs e)
        {
            try
            {
                string desc;

                if (descTextBox.Text != "")
                {
                    desc = descTextBox.Text;
                    ordersTableAdapter.FillByContentByEmployee(ordersQuieriesDatabaseDataSet.Orders, desc);
                }
                else
                {
                    MessageBox.Show("Please enter a valid value");
                    descTextBox.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DisplayByCPRButton_Click(object sender, EventArgs e)
        {
            try
            {
                string CPR;

                if (CPRTextBox.Text != "")
                {
                    CPR = CPRTextBox.Text;
                    ordersTableAdapter.FillByCustomerCPR(ordersQuieriesDatabaseDataSet.Orders, CPR);
                }
                else
                {
                    MessageBox.Show("Please enter a valid value");
                    CPRTextBox.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void firstPictureBox_Click(object sender, EventArgs e)
        {
            try
            {
                ordersBindingSource.MoveFirst();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lastPictureBox_Click(object sender, EventArgs e)
        {
            try
            {
                ordersBindingSource.MoveLast();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void previousPictureBox_Click(object sender, EventArgs e)
        {
            try
            {
                ordersBindingSource.MovePrevious();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void NextPictureBox_Click(object sender, EventArgs e)
        {
            try
            {
                ordersBindingSource.MoveNext();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void savePictureBox_Click(object sender, EventArgs e)
        {
            try
            {
                ordersBindingSource.EndEdit();
                ordersTableAdapter.Update(ordersQuieriesDatabaseDataSet.Orders);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            fromTextBox.Text = "";
            toTextBox.Text = "";
            descTextBox.Text = "";
            CPRTextBox.Text = "";

            allOrdersRadioButton.Focus();
        }
    }
}
