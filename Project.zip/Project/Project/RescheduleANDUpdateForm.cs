﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class RescheduleANDUpdateForm : Form
    {
        public RescheduleANDUpdateForm()
        {
            InitializeComponent();
        }

        private void RescheduleANDUpdateForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'rescheduleDatabaseDataSet.Orders' table. You can move, or remove it, as needed.
            // this.ordersTableAdapter.Fill(this.rescheduleDatabaseDataSet.Orders);

        }

        private void continuetrackOrder_Click(object sender, EventArgs e)
        {
            string customerID;
            try
            {
                
                    if (CustomerIdtextBox.Text != "")
                    {
                        customerID = CustomerIdtextBox.Text;
                        // database retrive code 
                        ordersTableAdapter.FillByCustomerCPR(rescheduleDatabaseDataSet.Orders, customerID);
                    }
                    else
                    {
                        MessageBox.Show("Please enter customer id ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CustomerIdtextBox.Focus();

                    }
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            string destination, date;
            try
            {
                if (destinationTextBox.Text != "")
                {
                    destination = destinationTextBox.Text;

                    if(arrival_DateTextBox.Text != "")
                    {
                        date = arrival_DateTextBox.Text;

                        MessageBox.Show("Your  orders is updated sucessfully:)", " Information" , MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ordersBindingSource.EndEdit();
                        ordersTableAdapter.Update(rescheduleDatabaseDataSet.Orders);

                    }
                }
                else
                {
                    MessageBox.Show("Please enter a destination", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    destinationTextBox.Focus();    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    }
    }
}

